
import React from "react";

const games = [
  { name: "BGMI", image: "https://source.unsplash.com/featured/?bgmi,game", price: "Free" },
  { name: "PUBG", image: "https://source.unsplash.com/featured/?pubg,game", price: "$29.99" },
  { name: "Call of Duty", image: "https://source.unsplash.com/featured/?callofduty,game", price: "$59.99" },
  { name: "GTA V", image: "https://source.unsplash.com/featured/?gta5,game", price: "$19.99" },
  { name: "Fortnite", image: "https://source.unsplash.com/featured/?fortnite,game", price: "Free" },
  { name: "Valorant", image: "https://source.unsplash.com/featured/?valorant,game", price: "Free" },
  { name: "Elden Ring", image: "https://source.unsplash.com/featured/?eldenring,game", price: "$59.99" },
];

export default function App() {
  return (
    <div className="min-h-screen bg-black text-white font-sans">
      <header className="bg-gradient-to-r from-green-400 to-blue-500 p-6 text-center">
        <h1 className="text-4xl font-extrabold tracking-wide">🎮 Blink Gaming Store</h1>
        <p className="text-lg mt-2">Your ultimate destination for trending games</p>
      </header>

      <section className="relative">
        <img
          src="https://images.unsplash.com/photo-1614521451339-dc95f1f4ddc3?auto=format&fit=crop&w=1950&q=80"
          alt="Gaming Banner"
          className="w-full h-[400px] object-cover opacity-30"
        />
        <div className="absolute top-0 left-0 w-full h-full flex flex-col items-center justify-center text-center">
          <h2 className="text-5xl font-bold text-white drop-shadow-lg">Level Up Your Game</h2>
          <p className="mt-4 text-xl">Shop the most popular and powerful titles now</p>
        </div>
      </section>

      <section className="p-6">
        <h2 className="text-3xl font-bold mb-4">🔥 Featured Games</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {games.map((game, index) => (
            <div
              key={index}
              className="bg-gray-800 p-4 rounded-2xl shadow-lg hover:scale-105 transition transform duration-300"
            >
              <img
                src={game.image}
                alt={game.name}
                className="w-full h-48 object-cover rounded-xl mb-4"
              />
              <h3 className="text-xl font-semibold mb-2">{game.name}</h3>
              <p className="text-green-400 font-bold">{game.price}</p>
            </div>
          ))}
        </div>
      </section>

      <footer className="bg-gray-900 p-6 mt-8 text-center">
        <p>© 2025 Blink Gaming Store. All rights reserved.</p>
      </footer>
    </div>
  );
}
